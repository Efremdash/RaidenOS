section .multiboot
align 4

    ; ИСПРАВЛЕНИЕ:
    ; flags был 0, поэтому GRUB не знал,
    ; что ядро хочет графический (LFB) режим,
    ; и не заполнял framebuffer_* поля в
    ; multiboot_info (бит 12 flags оставался 0).
    ; framebuffer_available() всегда возвращал 0,
    ; и система молча откатывалась на VGA-текст -
    ; настройки gfxmode/gfxpayload в grub.cfg
    ; влияли только на меню GRUB, а не на ядро.
    ;
    ; Бит 2 (0x4) в заголовке = "хочу video mode
    ; info"; следом идут mode_type/width/height/depth -
    ; запрашиваем именно 1024x768x32, как в grub.cfg.

    dd 0x1BADB002                       ; magic
    dd 0x00000004                       ; flags: бит 2 = запрос видеорежима
    dd -(0x1BADB002 + 0x00000004)       ; checksum

    dd 0                                ; mode_type: 0 = linear graphics (LFB)
    dd 1024                             ; width
    dd 768                              ; height
    dd 32                               ; depth (bpp)


section .text

bits 32

global _start

extern kernel_main


_start:
    cli

    ; BOOT 1
    mov byte [0xB8000], '1'
    mov byte [0xB8001], 0x0F

    ; Сохраняем Multiboot
    mov [multiboot_magic], eax
    mov [multiboot_info], ebx

    ; BOOT 2
    mov byte [0xB8002], '2'
    mov byte [0xB8003], 0x0F

    ; Стек
    mov esp, stack_top

    ; BOOT 3
    mov byte [0xB8004], '3'
    mov byte [0xB8005], 0x0F

    ; Проверка Long Mode
    call check_long_mode

    ; BOOT 4
    mov byte [0xB8006], '4'
    mov byte [0xB8007], 0x0F

    ; Создание таблиц страниц
    call setup_page_tables

    ; BOOT 5
    mov byte [0xB8008], '5'
    mov byte [0xB8009], 0x0F

    ; Загружаем PML4
    mov eax, page_table_l4
    mov cr3, eax

    ; BOOT 6
    mov byte [0xB800A], '6'
    mov byte [0xB800B], 0x0F

    ; Загружаем GDT
    lgdt [gdt64_pointer]

    ; BOOT 7
    mov byte [0xB800C], '7'
    mov byte [0xB800D], 0x0F

    ; Включаем Long Mode
    call enable_long_mode

    ; BOOT 8
    mov byte [0xB800E], '8'
    mov byte [0xB800F], 0x0F

    ; Переход в 64-bit
    jmp 0x08:start_64


; ============================================================
; Проверка Long Mode
; ============================================================

check_long_mode:

    mov eax, 0x80000000
    cpuid

    cmp eax, 0x80000001
    jb no_long_mode

    mov eax, 0x80000001
    cpuid

    test edx, 1 << 29
    jz no_long_mode

    ret


no_long_mode:

    mov byte [0xB8000], 'N'
    mov byte [0xB8001], 0x4F

.hang:
    cli
    hlt
    jmp .hang


; ============================================================
; Таблицы страниц
;
; ИСПРАВЛЕНИЕ:
; Раньше identity-mapping покрывал только первые 16 MiB.
; Framebuffer (LFB), который GRUB включает через
; gfxmode/gfxpayload в grub.cfg, физически расположен
; далеко за пределами этих 16 MiB (в MMIO-области видеокарты,
; обычно сотни MiB - несколько GiB). Запись в framebuffer_clear()
; попадала на неотображённый адрес -> Page Fault ДО того, как
; была загружена IDT -> тройной фолт -> QEMU молча ребутится.
;
; Теперь identity-mapping покрывает первые 4 GiB физической
; памяти: первые 16 MiB - как раньше, обычными 4 KiB страницами
; (это нужно для демо-теста VMM в kernel.c, который перематывает
; отдельную 4 KiB страницу), а всё остальное до 4 GiB - через
; 2 MiB huge pages (бит PS), что почти не требует памяти под
; сами таблицы и гарантированно покрывает любой реальный адрес
; LFB, который выдаёт QEMU.
; ============================================================

setup_page_tables:

    ; =========================
    ; PML4 -> PDP
    ; =========================

    mov eax, page_table_l3
    or eax, 0b11
    mov [page_table_l4], eax


    ; =========================
    ; PDP -> Page Directory (0 - 1 GiB)
    ; =========================

    mov eax, page_table_l2
    or eax, 0b11
    mov [page_table_l3], eax


    ; =========================
    ; PDP -> дополнительные Page Directory
    ; (1-2, 2-3, 3-4 GiB), каждая целиком
    ; отображена 2 MiB huge pages
    ; =========================

    mov eax, page_table_l2_hi1
    or eax, 0b11
    mov [page_table_l3 + 8], eax

    mov eax, page_table_l2_hi2
    or eax, 0b11
    mov [page_table_l3 + 16], eax

    mov eax, page_table_l2_hi3
    or eax, 0b11
    mov [page_table_l3 + 24], eax


    ; =========================
    ; L2 -> L1 tables (0 - 16 MiB, 4 KiB страницы)
    ; =========================

    mov eax, page_table_l1
    or eax, 0b11
    mov [page_table_l2], eax

    mov eax, page_table_l1_2
    or eax, 0b11
    mov [page_table_l2 + 8], eax

    mov eax, page_table_l1_3
    or eax, 0b11
    mov [page_table_l2 + 16], eax

    mov eax, page_table_l1_4
    or eax, 0b11
    mov [page_table_l2 + 24], eax

    mov eax, page_table_l1_5
    or eax, 0b11
    mov [page_table_l2 + 32], eax

    mov eax, page_table_l1_6
    or eax, 0b11
    mov [page_table_l2 + 40], eax

    mov eax, page_table_l1_7
    or eax, 0b11
    mov [page_table_l2 + 48], eax

    mov eax, page_table_l1_8
    or eax, 0b11
    mov [page_table_l2 + 56], eax


    ; =========================
    ; L1 #1 = 0 - 2 MiB
    ; =========================

    mov edi, page_table_l1
    mov eax, 0x00000003
    mov ecx, 512

.map_page_1:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_1


    ; =========================
    ; L1 #2 = 2 - 4 MiB
    ; =========================

    mov edi, page_table_l1_2
    mov eax, 0x00200003
    mov ecx, 512

.map_page_2:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_2


    ; =========================
    ; L1 #3 = 4 - 6 MiB
    ; =========================

    mov edi, page_table_l1_3
    mov eax, 0x00400003
    mov ecx, 512

.map_page_3:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_3


    ; =========================
    ; L1 #4 = 6 - 8 MiB
    ; =========================

    mov edi, page_table_l1_4
    mov eax, 0x00600003
    mov ecx, 512

.map_page_4:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_4


    ; =========================
    ; L1 #5 = 8 - 10 MiB
    ; =========================

    mov edi, page_table_l1_5
    mov eax, 0x00800003
    mov ecx, 512

.map_page_5:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_5


    ; =========================
    ; L1 #6 = 10 - 12 MiB
    ; =========================

    mov edi, page_table_l1_6
    mov eax, 0x00A00003
    mov ecx, 512

.map_page_6:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_6


    ; =========================
    ; L1 #7 = 12 - 14 MiB
    ; =========================

    mov edi, page_table_l1_7
    mov eax, 0x00C00003
    mov ecx, 512

.map_page_7:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_7


    ; =========================
    ; L1 #8 = 14 - 16 MiB
    ; =========================

    mov edi, page_table_l1_8
    mov eax, 0x00E00003
    mov ecx, 512

.map_page_8:
    mov [edi], eax
    add eax, 0x1000
    add edi, 8
    loop .map_page_8


    ; =========================
    ; L2 (page_table_l2), записи 8-511 = 16 MiB - 1 GiB
    ; через 2 MiB huge pages (бит PS = бит 7 -> 0x83)
    ; =========================

    mov edi, page_table_l2
    add edi, 8 * 8              ; пропускаем первые 8 записей (уже заняты L1-таблицами)
    mov eax, 0x01000083         ; физ. адрес 16 MiB | present+write+PS
    mov ecx, 504                ; 512 - 8 записей

.map_l2_16m_to_1g:
    mov [edi], eax
    add eax, 0x200000
    add edi, 8
    loop .map_l2_16m_to_1g


    ; =========================
    ; L2 hi1 (1 - 2 GiB), 512 huge pages
    ; =========================

    mov edi, page_table_l2_hi1
    mov eax, 0x40000083
    mov ecx, 512

.map_l2_hi1:
    mov [edi], eax
    add eax, 0x200000
    add edi, 8
    loop .map_l2_hi1


    ; =========================
    ; L2 hi2 (2 - 3 GiB), 512 huge pages
    ; =========================

    mov edi, page_table_l2_hi2
    mov eax, 0x80000083
    mov ecx, 512

.map_l2_hi2:
    mov [edi], eax
    add eax, 0x200000
    add edi, 8
    loop .map_l2_hi2


    ; =========================
    ; L2 hi3 (3 - 4 GiB), 512 huge pages
    ; =========================

    mov edi, page_table_l2_hi3
    mov eax, 0xC0000083
    mov ecx, 512

.map_l2_hi3:
    mov [edi], eax
    add eax, 0x200000
    add edi, 8
    loop .map_l2_hi3

    ret


; ============================================================
; Включение Long Mode
; ============================================================

enable_long_mode:

    ; Enable PAE
    mov eax, cr4
    or eax, 1 << 5
    mov cr4, eax

    ; Enable Long Mode in EFER
    mov ecx, 0xC0000080
    rdmsr

    or eax, 1 << 8

    wrmsr

    ; Enable Paging
    mov eax, cr0
    or eax, 1 << 31
    mov cr0, eax

    ret


; ============================================================
; 64-bit code
; ============================================================

bits 64

start_64:

    ; BOOT 9
    mov byte [0xB8000], '9'
    mov byte [0xB8001], 0x0F

    mov ax, 0x10

    mov ds, ax
    mov es, ax
    mov ss, ax

    mov rsp, stack_top

    ; Передаём Multiboot в C
    mov edi, [multiboot_magic]
    mov esi, [multiboot_info]

    ; BOOT A
    mov byte [0xB8002], 'A'
    mov byte [0xB8003], 0x0F

    call kernel_main

.hang:

    cli
    hlt
    jmp .hang


; ============================================================
; GDT
; ============================================================

section .rodata

align 8

gdt64:

    dq 0x0000000000000000
    dq 0x00209A0000000000
    dq 0x0000920000000000

gdt64_pointer:

    dw gdt64_pointer - gdt64 - 1
    dq gdt64


; ============================================================
; BSS
; ============================================================

section .bss

align 4

multiboot_magic:
    resd 1

multiboot_info:
    resd 1


align 4096

global page_table_l4
page_table_l4:
    resb 4096

global page_table_l3
page_table_l3:
    resb 4096

global page_table_l2
page_table_l2:
    resb 4096

global page_table_l1
page_table_l1:
    resb 4096

global page_table_l1_2
page_table_l1_2:
    resb 4096

global page_table_l1_3
page_table_l1_3:
    resb 4096

global page_table_l1_4
page_table_l1_4:
    resb 4096

global page_table_l1_5
page_table_l1_5:
    resb 4096

global page_table_l1_6
page_table_l1_6:
    resb 4096

global page_table_l1_7
page_table_l1_7:
    resb 4096

global page_table_l1_8
page_table_l1_8:
    resb 4096

; Дополнительные Page Directory для identity-mapping
; диапазонов 1-2, 2-3, 3-4 GiB (2 MiB huge pages).
; Нужны, чтобы покрыть физический адрес LFB framebuffer,
; который лежит далеко за пределами первых 16 MiB.

global page_table_l2_hi1
page_table_l2_hi1:
    resb 4096

global page_table_l2_hi2
page_table_l2_hi2:
    resb 4096

global page_table_l2_hi3
page_table_l2_hi3:
    resb 4096


align 16

stack_bottom:
    resb 16384

stack_top:
