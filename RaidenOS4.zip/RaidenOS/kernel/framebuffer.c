#include "framebuffer.h"
#include "multiboot.h"
#include <stdint.h>
#include <stddef.h>

/*
 * ИСПРАВЛЕНИЕ: адрес framebuffer хранится как uint64_t.
 * info->framebuffer_addr - это 64-битное поле Multiboot;
 * раньше оно обрезалось до 32 бит при присваивании,
 * что могло дать неверный адрес на системах с LFB
 * выше 4 GiB. Не была основной причиной краха (в QEMU
 * LFB всегда ниже 4 GiB), но потенциальный источник
 * будущих багов, поэтому исправлено заодно.
 */
static uint64_t fb_addr = 0;
static uint32_t fb_width = 0;
static uint32_t fb_height = 0;
static uint32_t fb_pitch = 0;
static uint32_t fb_bpp = 0;
static int fb_available = 0;

void framebuffer_init(uint32_t magic, uint32_t multiboot_info_addr) {
    if (magic != 0x2BADB002) {
        fb_available = 0;
        return;
    }
    
    multiboot_info_t* info = (multiboot_info_t*)multiboot_info_addr;
    
    // Проверяем флаг framebuffer
    if (!(info->flags & (1 << 12))) {
        fb_available = 0;
        return;
    }
    
    fb_addr = info->framebuffer_addr;
    fb_width = info->framebuffer_width;
    fb_height = info->framebuffer_height;
    fb_pitch = info->framebuffer_pitch;
    fb_bpp = info->framebuffer_bpp;
    
    fb_available = (fb_addr != 0 && fb_width > 0 && fb_height > 0);
}

int framebuffer_available(void) {
    return fb_available;
}

uint32_t framebuffer_get_width(void) {
    return fb_width;
}

uint32_t framebuffer_get_height(void) {
    return fb_height;
}

void framebuffer_clear(uint32_t color) {
    if (!fb_available) return;
    
    for (uint32_t y = 0; y < fb_height; y++) {
        for (uint32_t x = 0; x < fb_width; x++) {
            uint32_t* pixel = (uint32_t*)(fb_addr + y * fb_pitch + x * (fb_bpp / 8));
            *pixel = color;
        }
    }
}

// НОВАЯ ФУНКЦИЯ - рисует залитый прямоугольник
void framebuffer_fill_rect(uint32_t x, uint32_t y, uint32_t width, uint32_t height, uint32_t color) {
    if (!fb_available) return;
    
    // Проверяем границы
    if (x >= fb_width || y >= fb_height) return;
    if (x + width > fb_width) width = fb_width - x;
    if (y + height > fb_height) height = fb_height - y;
    
    uint32_t bytes_per_pixel = fb_bpp / 8;
    
    for (uint32_t row = 0; row < height; row++) {
        for (uint32_t col = 0; col < width; col++) {
            uint32_t* pixel = (uint32_t*)(fb_addr + (y + row) * fb_pitch + (x + col) * bytes_per_pixel);
            *pixel = color;
        }
    }
}

void framebuffer_draw_char(uint32_t x, uint32_t y, char c, uint32_t color, uint32_t scale) {
    if (!fb_available || !c || c < 32) return;
    
    // Простой 5x7 шрифт (только заглавные буквы и цифры)
    static const uint8_t font[][5] = {
        // A-Z (0-25)
        {0x7E, 0x09, 0x09, 0x09, 0x7E}, // A
        {0x7F, 0x49, 0x49, 0x49, 0x36}, // B
        {0x3E, 0x41, 0x41, 0x41, 0x22}, // C
        {0x7F, 0x41, 0x41, 0x41, 0x3E}, // D
        {0x7F, 0x49, 0x49, 0x49, 0x41}, // E
        {0x7F, 0x09, 0x09, 0x09, 0x01}, // F
        {0x3E, 0x41, 0x49, 0x49, 0x3A}, // G
        {0x7F, 0x08, 0x08, 0x08, 0x7F}, // H
        {0x41, 0x41, 0x7F, 0x41, 0x41}, // I
        {0x20, 0x40, 0x41, 0x3F, 0x01}, // J
        {0x7F, 0x08, 0x14, 0x22, 0x41}, // K
        {0x7F, 0x40, 0x40, 0x40, 0x40}, // L
        {0x7F, 0x02, 0x0C, 0x02, 0x7F}, // M
        {0x7F, 0x02, 0x04, 0x08, 0x7F}, // N
        {0x3E, 0x41, 0x41, 0x41, 0x3E}, // O
        {0x7F, 0x09, 0x09, 0x09, 0x06}, // P
        {0x3E, 0x41, 0x51, 0x21, 0x5E}, // Q
        {0x7F, 0x09, 0x19, 0x29, 0x46}, // R
        {0x46, 0x49, 0x49, 0x49, 0x31}, // S
        {0x01, 0x01, 0x7F, 0x01, 0x01}, // T
        {0x3F, 0x40, 0x40, 0x40, 0x3F}, // U
        {0x1F, 0x20, 0x40, 0x20, 0x1F}, // V
        {0x7F, 0x20, 0x18, 0x20, 0x7F}, // W
        {0x63, 0x14, 0x08, 0x14, 0x63}, // X
        {0x03, 0x04, 0x78, 0x04, 0x03}, // Y
        {0x61, 0x51, 0x49, 0x45, 0x43}  // Z
    };
    
    int idx;
    if (c >= 'A' && c <= 'Z') {
        idx = c - 'A';
    } else if (c >= 'a' && c <= 'z') {
        idx = c - 'a';
    } else {
        return; // Неподдерживаемый символ
    }
    
    for (int row = 0; row < 5; row++) {
        uint8_t line = font[idx][row];
        for (int col = 0; col < 5; col++) {
            if (line & (1 << (4 - col))) {
                for (uint32_t dy = 0; dy < scale; dy++) {
                    for (uint32_t dx = 0; dx < scale; dx++) {
                        uint32_t px = x + col * scale + dx;
                        uint32_t py = y + row * scale + dy;
                        if (px < fb_width && py < fb_height) {
                            uint32_t* pixel = (uint32_t*)(fb_addr + py * fb_pitch + px * (fb_bpp / 8));
                            *pixel = color;
                        }
                    }
                }
            }
        }
    }
}

void framebuffer_draw_string(uint32_t x, uint32_t y, const char* str, uint32_t color, uint32_t scale) {
    if (!fb_available || !str) return;
    
    uint32_t cx = x;
    uint32_t cy = y;
    
    while (*str) {
        if (*str == '\n') {
            cx = x;
            cy += 5 * scale + 4;
        } else if (*str >= 'A' && *str <= 'Z') {
            framebuffer_draw_char(cx, cy, *str, color, scale);
            cx += 5 * scale + 2;
        } else if (*str >= 'a' && *str <= 'z') {
            framebuffer_draw_char(cx, cy, *str, color, scale);
            cx += 5 * scale + 2;
        } else if (*str == ' ') {
            cx += 5 * scale + 2;
        } else if (*str >= '0' && *str <= '9') {
            // Для цифр используем буквы A-J (0-9)
            framebuffer_draw_char(cx, cy, 'A' + (*str - '0'), color, scale);
            cx += 5 * scale + 2;
        }
        str++;
    }
}
