#include "irq.h"

#include "io.h"
#include "pic.h"
#include "pit.h"


static volatile uint64_t irq_counts[16];

static volatile uint64_t keyboard_count = 0;


void irq_handler(
    uint64_t irq
)
{
    if (irq >= 16)
    {
        return;
    }


    irq_counts[irq]++;


    /*
     * IRQ0 = PIT timer.
     */

    if (irq == 0)
    {
        pit_tick();
    }


    /*
     * IRQ1 = keyboard.
     */

    if (irq == 1)
    {
        /*
         * Читаем scancode.
         *
         * Даже если пока ничего
         * не отображаем, порт нужно
         * прочитать.
         */

        uint8_t scancode =
            inb(0x60);

        (void)scancode;

        keyboard_count++;
    }


    /*
     * Сообщаем PIC,
     * что обработка IRQ закончена.
     */

    pic_send_eoi(
        (uint8_t)irq
    );
}


uint64_t irq_get_count(
    uint8_t irq
)
{
    if (irq >= 16)
    {
        return 0;
    }

    return irq_counts[irq];
}


uint64_t keyboard_get_count(void)
{
    return keyboard_count;
}


void irq_init(void)
{
    for (int i = 0; i < 16; i++)
    {
        irq_counts[i] = 0;
    }

    keyboard_count = 0;
}
