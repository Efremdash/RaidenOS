#include "heap.h"

#include "pmm.h"
#include "vmm.h"


#define HEAP_START 0x00800000ULL


typedef struct
{
    uint64_t virtual_address;
    uint64_t page_count;
    uint64_t size;
    int used;

} heap_allocation_t;


#define MAX_ALLOCATIONS 128


static uint64_t heap_next =
    HEAP_START;


static heap_allocation_t allocations[
    MAX_ALLOCATIONS
];


void heap_init(void)
{
    heap_next =
        HEAP_START;

    for (int i = 0;
         i < MAX_ALLOCATIONS;
         i++)
    {
        allocations[i].used =
            0;

        allocations[i].virtual_address =
            0;

        allocations[i].page_count =
            0;

        allocations[i].size =
            0;
    }
}


void* kmalloc(uint64_t size)
{
    if (size == 0)
    {
        return 0;
    }


    uint64_t pages =
        (size + PAGE_SIZE - 1)
        / PAGE_SIZE;


    int allocation_index =
        -1;


    /*
     * Ищем свободную запись
     * в таблице аллокаций.
     */
    for (int i = 0;
         i < MAX_ALLOCATIONS;
         i++)
    {
        if (!allocations[i].used)
        {
            allocation_index =
                i;

            break;
        }
    }


    if (allocation_index == -1)
    {
        return 0;
    }


    uint64_t start =
        heap_next;


    /*
     * Выделяем физические страницы
     * и отображаем их.
     */
    for (uint64_t i = 0;
         i < pages;
         i++)
    {
        uint64_t physical =
            pmm_alloc_page();


        /*
         * Если физическая память
         * закончилась — откатываем.
         */
        if (physical == 0)
        {
            for (uint64_t j = 0;
                 j < i;
                 j++)
            {
                uint64_t virtual_address =
                    start + j * PAGE_SIZE;


                uint64_t allocated_physical =
                    vmm_get_physical_address(
                        virtual_address
                    );


                if (allocated_physical != 0)
                {
                    vmm_unmap_page(
                        virtual_address
                    );

                    pmm_free_page(
                        allocated_physical
                    );
                }
            }


            return 0;
        }


        uint64_t virtual_address =
            start + i * PAGE_SIZE;


        /*
         * Создаём виртуальное отображение.
         */
        if (!vmm_map_page(
                virtual_address,
                physical
            ))
        {
            pmm_free_page(
                physical
            );


            /*
             * Откатываем предыдущие страницы.
             */
            for (uint64_t j = 0;
                 j < i;
                 j++)
            {
                uint64_t previous_virtual =
                    start + j * PAGE_SIZE;


                uint64_t previous_physical =
                    vmm_get_physical_address(
                        previous_virtual
                    );


                if (previous_physical != 0)
                {
                    vmm_unmap_page(
                        previous_virtual
                    );

                    pmm_free_page(
                        previous_physical
                    );
                }
            }


            return 0;
        }
    }


    /*
     * Записываем информацию
     * об аллокации.
     */
    allocations[allocation_index].used =
        1;


    allocations[allocation_index].virtual_address =
        start;


    allocations[allocation_index].page_count =
        pages;


    allocations[allocation_index].size =
        size;


    /*
     * Следующая выдаваемая область.
     */
    heap_next +=
        pages * PAGE_SIZE;


    return (void*)start;
}


void kfree(void* pointer)
{
    if (pointer == 0)
    {
        return;
    }


    uint64_t address =
        (uint64_t)pointer;


    /*
     * Ищем эту аллокацию.
     */
    for (int i = 0;
         i < MAX_ALLOCATIONS;
         i++)
    {
        if (!allocations[i].used)
        {
            continue;
        }


        if (allocations[i].virtual_address != address)
        {
            continue;
        }


        uint64_t start =
            allocations[i].virtual_address;


        uint64_t pages =
            allocations[i].page_count;


        /*
         * Освобождаем все страницы.
         */
        for (uint64_t page = 0;
             page < pages;
             page++)
        {
            uint64_t virtual_address =
                start + page * PAGE_SIZE;


            /*
             * Сначала узнаём,
             * какая физическая страница
             * здесь находится.
             */
            uint64_t physical =
                vmm_get_physical_address(
                    virtual_address
                );


            /*
             * Возвращаем физическую страницу
             * в PMM.
             */
            if (physical != 0)
            {
                pmm_free_page(
                    physical
                );
            }


            /*
             * Теперь удаляем виртуальное
             * отображение.
             */
            vmm_unmap_page(
                virtual_address
            );
        }


        /*
         * Освобождаем запись аллокации.
         */
        allocations[i].used =
            0;


        allocations[i].virtual_address =
            0;


        allocations[i].page_count =
            0;


        allocations[i].size =
            0;


        return;
    }
}
