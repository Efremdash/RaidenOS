#ifndef IDT_H
#define IDT_H

#include <stdint.h>


/*
 * Одна запись IDT.
 *
 * Для x86-64 адрес обработчика
 * разбивается на три части.
 */
typedef struct
{
    uint16_t offset_low;

    uint16_t selector;

    uint8_t ist;

    uint8_t type_attributes;

    uint16_t offset_middle;

    uint32_t offset_high;

    uint32_t zero;

} __attribute__((packed)) idt_entry_t;


/*
 * Указатель на IDT.
 */
typedef struct
{
    uint16_t limit;

    uint64_t base;

} __attribute__((packed)) idt_pointer_t;


/*
 * Инициализация IDT.
 */
void idt_init(void);


/*
 * Установить одну запись IDT.
 */
void idt_set_gate(
    int vector,
    void (*handler)(void)
);


/*
 * Обработчик исключения,
 * вызываемый из Assembly.
 */
void exception_handler(
    uint64_t vector
);

#endif
