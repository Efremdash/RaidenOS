#ifndef IRQ_H
#define IRQ_H

#include <stdint.h>


void irq_init(void);

void irq_handler(
    uint64_t irq
);

uint64_t irq_get_count(
    uint8_t irq
);

uint64_t keyboard_get_count(void);

#endif
