#include "vmm.h"

extern uint64_t page_table_l1[];
extern uint64_t page_table_l1_2[];
extern uint64_t page_table_l1_3[];
extern uint64_t page_table_l1_4[];
extern uint64_t page_table_l1_5[];
extern uint64_t page_table_l1_6[];
extern uint64_t page_table_l1_7[];
extern uint64_t page_table_l1_8[];


void vmm_init(void)
{
}


/*
 * Получить таблицу страниц
 * для виртуального адреса.
 */
static uint64_t* get_page_table(
    uint64_t virtual_address
)
{
    uint64_t page =
        virtual_address / PAGE_SIZE;

    if (page >= 4096)
    {
        return 0;
    }

    uint64_t table =
        page / 512;

    switch (table)
    {
        case 0:
            return page_table_l1;

        case 1:
            return page_table_l1_2;

        case 2:
            return page_table_l1_3;

        case 3:
            return page_table_l1_4;

        case 4:
            return page_table_l1_5;

        case 5:
            return page_table_l1_6;

        case 6:
            return page_table_l1_7;

        case 7:
            return page_table_l1_8;

        default:
            return 0;
    }
}


/*
 * Преобразовать виртуальный адрес
 * в физический адрес.
 */
uint64_t vmm_get_physical_address(
    uint64_t virtual_address
)
{
    if (virtual_address % PAGE_SIZE != 0)
    {
        return 0;
    }

    uint64_t page =
        virtual_address / PAGE_SIZE;

    if (page >= 4096)
    {
        return 0;
    }

    uint64_t* table =
        get_page_table(
            virtual_address
        );

    if (table == 0)
    {
        return 0;
    }

    uint64_t index =
        page % 512;

    uint64_t entry =
        table[index];

    /*
     * Если страница не отображена.
     */
    if ((entry & 1) == 0)
    {
        return 0;
    }

    /*
     * Убираем флаги
     * и оставляем физический адрес.
     */
    return entry &
        0x000FFFFFFFFFF000ULL;
}


/*
 * Отобразить физическую страницу
 * на виртуальный адрес.
 */
int vmm_map_page(
    uint64_t virtual_address,
    uint64_t physical_address
)
{
    if (virtual_address % PAGE_SIZE != 0)
    {
        return 0;
    }

    if (physical_address % PAGE_SIZE != 0)
    {
        return 0;
    }

    uint64_t page =
        virtual_address / PAGE_SIZE;

    if (page >= 4096)
    {
        return 0;
    }

    uint64_t* table =
        get_page_table(
            virtual_address
        );

    if (table == 0)
    {
        return 0;
    }

    uint64_t index =
        page % 512;

    table[index] =
        physical_address | 0x03;

    asm volatile (
        "invlpg (%0)"
        :
        : "r"(virtual_address)
        : "memory"
    );

    return 1;
}


/*
 * Удалить отображение
 * виртуальной страницы.
 */
void vmm_unmap_page(
    uint64_t virtual_address
)
{
    if (virtual_address % PAGE_SIZE != 0)
    {
        return;
    }

    uint64_t page =
        virtual_address / PAGE_SIZE;

    if (page >= 4096)
    {
        return;
    }

    uint64_t* table =
        get_page_table(
            virtual_address
        );

    if (table == 0)
    {
        return;
    }

    uint64_t index =
        page % 512;

    table[index] = 0;

    asm volatile (
        "invlpg (%0)"
        :
        : "r"(virtual_address)
        : "memory"
    );
}
