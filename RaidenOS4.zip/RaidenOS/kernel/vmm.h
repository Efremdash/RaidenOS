#ifndef VMM_H
#define VMM_H

#include <stdint.h>

#define PAGE_SIZE 4096

void vmm_init(void);

int vmm_map_page(
    uint64_t virtual_address,
    uint64_t physical_address
);

void vmm_unmap_page(
    uint64_t virtual_address
);

uint64_t vmm_get_physical_address(
    uint64_t virtual_address
);

#endif
