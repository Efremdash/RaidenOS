#include "pit.h"

#include "io.h"


#define PIT_FREQUENCY 1193182


static volatile uint64_t ticks = 0;


void pit_init(
    uint32_t frequency
)
{
    if (frequency == 0)
    {
        frequency = 100;
    }


    uint32_t divisor =
        PIT_FREQUENCY / frequency;


    if (divisor < 1)
    {
        divisor = 1;
    }


    if (divisor > 65535)
    {
        divisor = 65535;
    }


    /*
     * Channel 0
     * Access: low byte + high byte
     * Mode 3: square wave
     */

    outb(
        0x43,
        0x36
    );


    outb(
        0x40,
        divisor & 0xFF
    );


    outb(
        0x40,
        (divisor >> 8) & 0xFF
    );
}


void pit_tick(void)
{
    ticks++;
}


uint64_t pit_get_ticks(void)
{
    return ticks;
}
