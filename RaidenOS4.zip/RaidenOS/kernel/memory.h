#ifndef MEMORY_H
#define MEMORY_H

#include <stdint.h>


typedef struct __attribute__((packed))
{
    uint32_t size;

    uint64_t base;

    uint64_t length;

    uint32_t type;

} multiboot_mmap_entry_t;


void memory_init(
    uint32_t magic,
    uint32_t multiboot_info
);

#endif
