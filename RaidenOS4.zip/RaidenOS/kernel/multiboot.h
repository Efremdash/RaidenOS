#ifndef MULTIBOOT_H
#define MULTIBOOT_H

#include <stdint.h>

typedef struct {
    uint32_t flags;
    uint32_t mem_lower;
    uint32_t mem_upper;
    uint32_t boot_device;
    uint32_t cmdline;
    uint32_t mods_count;
    uint32_t mods_addr;
    uint32_t syms[4];
    uint32_t mmap_length;
    uint32_t mmap_addr;
    uint32_t drives_length;
    uint32_t drives_addr;
    uint32_t config_table;
    uint32_t boot_loader_name;
    uint32_t apm_table;
    uint32_t vbe_control_info;
    uint32_t vbe_mode_info;

    /*
     * ИСПРАВЛЕНИЕ: по спецификации Multiboot 1
     * эти 4 поля - uint16_t, а не uint32_t.
     * Из-за неверного размера (было 16 байт
     * вместо правильных 8) все поля ниже,
     * включая framebuffer_addr, читались
     * со сдвигом на 8 байт - framebuffer_addr
     * получался мусорным огромным числом
     * (фактически - байты framebuffer_pitch
     * и framebuffer_width настоящей структуры),
     * что вызывало Page Fault при первой же
     * записи в "framebuffer".
     */
    uint16_t vbe_mode;
    uint16_t vbe_interface_seg;
    uint16_t vbe_interface_off;
    uint16_t vbe_interface_len;

    uint64_t framebuffer_addr;
    uint32_t framebuffer_pitch;
    uint32_t framebuffer_width;
    uint32_t framebuffer_height;

    /*
     * ИСПРАВЛЕНИЕ: framebuffer_bpp - это uint8_t,
     * а не uint32_t (было ещё +3 лишних байта сдвига).
     */
    uint8_t framebuffer_bpp;
    uint8_t framebuffer_type;
    uint8_t color_info[6];
} __attribute__((packed)) multiboot_info_t;

#endif
