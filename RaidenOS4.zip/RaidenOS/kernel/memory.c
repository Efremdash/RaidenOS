#include "memory.h"

static volatile char* video = (volatile char*)0xB8000;

static int row = 1;
static int column = 0;


/*
 * Печать текста.
 */
static void print(const char* text)
{
    while (*text)
    {
        if (*text == '\n')
        {
            column = 0;
            row++;

            /*
             * Если дошли до конца экрана,
             * начинаем снова с последней строки.
             */
            if (row >= 25)
            {
                row = 24;
            }
        }
        else
        {
            int position = row * 80 + column;

            video[position * 2] = *text;
            video[position * 2 + 1] = 0x0F;

            column++;

            if (column >= 80)
            {
                column = 0;
                row++;

                if (row >= 25)
                {
                    row = 24;
                }
            }
        }

        text++;
    }
}


/*
 * Печать 64-битного числа в HEX.
 */
static void print_hex(uint64_t value)
{
    const char* digits = "0123456789ABCDEF";

    print("0x");

    for (int i = 15; i >= 0; i--)
    {
        int shift = i * 4;

        char digit = digits[(value >> shift) & 0xF];

        int position = row * 80 + column;

        video[position * 2] = digit;
        video[position * 2 + 1] = 0x0F;

        column++;

        if (column >= 80)
        {
            column = 0;
            row++;

            if (row >= 25)
            {
                row = 24;
            }
        }
    }
}


/*
 * Печать обычного числа.
 */
static void print_uint64(uint64_t value)
{
    char buffer[20];

    int index = 0;


    if (value == 0)
    {
        print("0");
        return;
    }


    while (value > 0)
    {
        buffer[index++] = '0' + (value % 10);

        value /= 10;
    }


    while (index > 0)
    {
        index--;

        char character = buffer[index];

        int position = row * 80 + column;

        video[position * 2] = character;
        video[position * 2 + 1] = 0x0F;

        column++;

        if (column >= 80)
        {
            column = 0;
            row++;

            if (row >= 25)
            {
                row = 24;
            }
        }
    }
}


/*
 * Multiboot Memory Map entry.
 */



/*
 * Memory Manager.
 */
void memory_init(uint32_t magic, uint32_t multiboot_info)
{
    /*
     * Проверяем Multiboot.
     */
    if (magic != 0x2BADB002)
    {
        print("MEMORY MANAGER: ERROR\n");
        print("MULTIBOOT: INVALID\n");

        return;
    }


    print("MEMORY MANAGER: ONLINE\n");

    print("MULTIBOOT: VALID\n");


    /*
     * Получаем Multiboot Information Structure.
     */
    uint32_t* info = (uint32_t*)multiboot_info;

    uint32_t flags = info[0];


    print("FLAGS: ");
    print_hex(flags);
    print("\n");


    /*
     * Проверяем Memory Map.
     */
    if (!(flags & (1 << 6)))
    {
        print("MEMORY MAP: NOT AVAILABLE\n");

        return;
    }


    print("MEMORY MAP: AVAILABLE\n");


    /*
     * Адрес и размер Memory Map.
     */
    uint32_t mmap_length = info[11];

    uint32_t mmap_addr = info[12];


    print("MAP ADDRESS: ");
    print_hex(mmap_addr);
    print("\n");


    print("MAP LENGTH: ");
    print_hex(mmap_length);
    print("\n");


    /*
     * Начало Memory Map.
     */
    uint32_t current = mmap_addr;

    uint32_t end = mmap_addr + mmap_length;


    /*
     * Общий объём доступной RAM.
     */
    uint64_t available_memory = 0;


    /*
     * Количество регионов.
     */
    uint64_t region_count = 0;


    /*
     * Проходим по всем регионам.
     */
    while (current < end)
    {
        multiboot_mmap_entry_t* entry =
            (multiboot_mmap_entry_t*)current;


        /*
         * TYPE 1 = доступная RAM.
         */
        if (entry->type == 1)
        {
            available_memory += entry->length;
        }


        region_count++;


        /*
         * Проверяем размер записи.
         */
        if (entry->size < 20)
        {
            break;
        }


        /*
         * Переходим к следующей записи.
         */
        current += entry->size + sizeof(entry->size);
    }


    /*
     * Теперь выводим итог.
     *
     * Он находится в самом низу,
     * поэтому подробный список регионов
     * больше не вытесняет его с экрана.
     */
    print("\n");
    print("================================\n");

    print("MEMORY INFORMATION\n");

    print("================================\n");


    print("REGIONS: ");

    print_uint64(region_count);

    print("\n");


    /*
     * Байты.
     */
    print("AVAILABLE BYTES: ");

    print_uint64(available_memory);

    print("\n");


    /*
     * Килобайты.
     */
    uint64_t available_kb =
        available_memory / 1024;

    print("AVAILABLE KB: ");

    print_uint64(available_kb);

    print("\n");


    /*
     * Мегабайты.
     */
    uint64_t available_mb =
        available_memory / (1024 * 1024);

    print("AVAILABLE MB: ");

    print_uint64(available_mb);

    print("\n");


    print("================================\n");

    print("MEMORY MANAGER: READY\n");
}

