#ifndef FRAMEBUFFER_H
#define FRAMEBUFFER_H

#include <stdint.h>

void framebuffer_init(uint32_t magic, uint32_t multiboot_info);
int framebuffer_available(void);
uint32_t framebuffer_get_width(void);
uint32_t framebuffer_get_height(void);

void framebuffer_clear(uint32_t color);
void framebuffer_fill_rect(uint32_t x, uint32_t y, uint32_t width, uint32_t height, uint32_t color);
void framebuffer_draw_char(uint32_t x, uint32_t y, char c, uint32_t color, uint32_t scale);
void framebuffer_draw_string(uint32_t x, uint32_t y, const char* str, uint32_t color, uint32_t scale);

#endif
