#include "pic.h"

#include "io.h"


void pic_send_eoi(
    uint8_t irq
)
{
    if (irq >= 8)
    {
        outb(
            PIC2_COMMAND,
            PIC_EOI
        );
    }

    outb(
        PIC1_COMMAND,
        PIC_EOI
    );
}


void pic_set_mask(
    uint8_t irq
)
{
    uint16_t port;

    if (irq < 8)
    {
        port = PIC1_DATA;
    }
    else
    {
        port = PIC2_DATA;
        irq -= 8;
    }

    uint8_t mask =
        inb(port);

    mask |=
        (1 << irq);

    outb(
        port,
        mask
    );
}


void pic_clear_mask(
    uint8_t irq
)
{
    uint16_t port;

    if (irq < 8)
    {
        port = PIC1_DATA;
    }
    else
    {
        port = PIC2_DATA;
        irq -= 8;
    }

    uint8_t mask =
        inb(port);

    mask &= ~(
        1 << irq
    );

    outb(
        port,
        mask
    );
}


void pic_init(void)
{
    uint8_t master_mask =
        inb(PIC1_DATA);

    uint8_t slave_mask =
        inb(PIC2_DATA);


    /*
     * Начинаем последовательность
     * инициализации PIC.
     */

    outb(
        PIC1_COMMAND,
        0x11
    );

    io_wait();

    outb(
        PIC2_COMMAND,
        0x11
    );

    io_wait();


    /*
     * Новые номера векторов.
     *
     * Master:
     * IRQ0-7 -> 32-39
     *
     * Slave:
     * IRQ8-15 -> 40-47
     */

    outb(
        PIC1_DATA,
        PIC1_OFFSET
    );

    io_wait();

    outb(
        PIC2_DATA,
        PIC2_OFFSET
    );

    io_wait();


    /*
     * Master PIC подключён
     * к Slave через IRQ2.
     */

    outb(
        PIC1_DATA,
        0x04
    );

    io_wait();

    outb(
        PIC2_DATA,
        0x02
    );

    io_wait();


    /*
     * Работаем в 8086 mode.
     */

    outb(
        PIC1_DATA,
        0x01
    );

    io_wait();

    outb(
        PIC2_DATA,
        0x01
    );

    io_wait();


    /*
     * Пока сохраняем исходные маски.
     */

    outb(
        PIC1_DATA,
        master_mask
    );

    outb(
        PIC2_DATA,
        slave_mask
    );


    /*
     * Отключаем все IRQ.
     *
     * Потом отдельно включим
     * только нужные.
     */

    outb(
        PIC1_DATA,
        0xFF
    );

    outb(
        PIC2_DATA,
        0xFF
    );


    /*
     * IRQ0 = PIT timer
     * IRQ1 = keyboard
     *
     * Они будут разрешены
     * после установки обработчиков.
     */

    pic_clear_mask(0);
    pic_clear_mask(1);
}
