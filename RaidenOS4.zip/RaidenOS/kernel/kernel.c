#include <stdint.h>

#include "memory.h"
#include "pmm.h"
#include "vmm.h"
#include "heap.h"
#include "idt.h"
#include "pic.h"
#include "irq.h"
#include "pit.h"
#include "framebuffer.h"


/*
 * ============================================================
 * COLORS
 * ============================================================
 */

#define COLOR_BACKGROUND 0x11131AFF
#define COLOR_PANEL      0x1B1E2AFF
#define COLOR_PANEL2     0x24283AFF
#define COLOR_TEXT       0xFFFFFFFF
#define COLOR_TEXT_DIM   0xAEB4C4FF
#define COLOR_ACCENT     0x9B7CFFFF
#define COLOR_SUCCESS    0x6FE7B7FF
#define COLOR_WARNING    0xF0C674FF


/*
 * ============================================================
 * VGA FALLBACK
 * ============================================================
 */

static volatile uint16_t* vga =
    (volatile uint16_t*)0xB8000;

static int cursor_row = 0;
static int cursor_col = 0;

static uint8_t vga_color = 0x0F;


static void vga_clear_screen(void)
{
    for (int y = 0; y < 25; y++)
    {
        for (int x = 0; x < 80; x++)
        {
            vga[y * 80 + x] =
                ((uint16_t)vga_color << 8) |
                ' ';
        }
    }

    cursor_row = 0;
    cursor_col = 0;
}


static void vga_newline(void)
{
    cursor_col = 0;
    cursor_row++;

    if (cursor_row >= 25)
    {
        cursor_row = 24;
    }
}


static void vga_print_char(
    char c
)
{
    if (c == '\n')
    {
        vga_newline();
        return;
    }

    if (cursor_col >= 80)
    {
        vga_newline();
    }

    vga[
        cursor_row * 80 +
        cursor_col
    ] =
        ((uint16_t)vga_color << 8) |
        (uint8_t)c;

    cursor_col++;
}


/*
 * ============================================================
 * GRAPHICS CONSOLE
 * ============================================================
 */

static uint32_t graphics_cursor_x = 32;

static uint32_t graphics_cursor_y = 150;

static uint32_t graphics_text_color =
    COLOR_TEXT;

static uint32_t graphics_scale = 3;


static void graphics_newline(void)
{
    graphics_cursor_x = 32;

    graphics_cursor_y +=
        28;
}


static void graphics_print_char(
    char c
)
{
    if (c == '\n')
    {
        graphics_newline();
        return;
    }


    if (c >= 'a' &&
        c <= 'z')
    {
        c -=
            'a' - 'A';
    }


    framebuffer_draw_char(
        graphics_cursor_x,
        graphics_cursor_y,
        c,
        graphics_text_color,
        graphics_scale
    );


    graphics_cursor_x +=
        6 * graphics_scale;
}


static void graphics_print(
    const char* text
)
{
    while (*text)
    {
        graphics_print_char(
            *text
        );

        text++;
    }
}


/*
 * ============================================================
 * GENERIC PRINT
 * ============================================================
 */

static void clear_screen(void)
{
    if (framebuffer_available())
    {
        framebuffer_clear(
            COLOR_BACKGROUND
        );

        graphics_cursor_x = 32;
        graphics_cursor_y = 150;

        return;
    }


    vga_clear_screen();
}


static void print_char(
    char c
)
{
    if (framebuffer_available())
    {
        graphics_print_char(c);
        return;
    }


    vga_print_char(c);
}


static void print(
    const char* text
)
{
    if (framebuffer_available())
    {
        graphics_print(text);
        return;
    }


    while (*text)
    {
        vga_print_char(*text);
        text++;
    }
}


/*
 * ============================================================
 * NUMBERS
 * ============================================================
 */

static void print_uint64(
    uint64_t value
)
{
    char buffer[32];

    int position = 0;


    if (value == 0)
    {
        print("0");
        return;
    }


    while (value > 0)
    {
        buffer[position++] =
            '0' + (value % 10);

        value /= 10;
    }


    while (position > 0)
    {
        position--;

        print_char(
            buffer[position]
        );
    }
}


static void print_hex(
    uint64_t value
)
{
    const char* digits =
        "0123456789ABCDEF";


    print("0x");


    int started = 0;


    for (int i = 15;
         i >= 0;
         i--)
    {
        uint8_t digit =
            (value >> (i * 4)) & 0xF;


        if (digit != 0 ||
            started ||
            i == 0)
        {
            print_char(
                digits[digit]
            );

            started = 1;
        }
    }
}


/*
 * ============================================================
 * EXCEPTIONS
 * ============================================================
 */

static const char* exception_name(
    uint64_t vector
)
{
    switch (vector)
    {
        case 0:
            return "DIVIDE BY ZERO";

        case 1:
            return "DEBUG";

        case 2:
            return "NON-MASKABLE INTERRUPT";

        case 3:
            return "BREAKPOINT";

        case 4:
            return "OVERFLOW";

        case 5:
            return "BOUND RANGE EXCEEDED";

        case 6:
            return "INVALID OPCODE";

        case 7:
            return "DEVICE NOT AVAILABLE";

        case 8:
            return "DOUBLE FAULT";

        case 9:
            return "COPROCESSOR SEGMENT OVERRUN";

        case 10:
            return "INVALID TSS";

        case 11:
            return "SEGMENT NOT PRESENT";

        case 12:
            return "STACK SEGMENT FAULT";

        case 13:
            return "GENERAL PROTECTION FAULT";

        case 14:
            return "PAGE FAULT";

        case 16:
            return "X87 FLOATING POINT";

        case 17:
            return "ALIGNMENT CHECK";

        case 18:
            return "MACHINE CHECK";

        case 19:
            return "SIMD FLOATING POINT";

        case 20:
            return "VIRTUALIZATION";

        case 21:
            return "CONTROL PROTECTION";

        case 29:
            return "VMM COMMUNICATION";

        case 30:
            return "SECURITY EXCEPTION";

        default:
            return "UNKNOWN EXCEPTION";
    }
}


void exception_handler(
    uint64_t vector
)
{
    asm volatile ("cli");


    if (framebuffer_available())
    {
        framebuffer_clear(
            0x190F18FF
        );


        framebuffer_fill_rect(
            0,
            0,
            framebuffer_get_width(),
            90,
            0x2B142DFF
        );


        framebuffer_draw_string(
            40,
            30,
            "RAIDEN OS KERNEL PANIC",
            COLOR_TEXT,
            4
        );


        framebuffer_draw_string(
            40,
            150,
            "CPU EXCEPTION",
            COLOR_WARNING,
            3
        );


        framebuffer_draw_string(
            40,
            200,
            "VECTOR:",
            COLOR_TEXT_DIM,
            3
        );


        framebuffer_draw_string(
            40,
            250,
            exception_name(vector),
            COLOR_TEXT,
            4
        );


        framebuffer_draw_string(
            40,
            340,
            "SYSTEM HALTED",
            COLOR_WARNING,
            4
        );
    }
    else
    {
        clear_screen();

        print("========================================\n");
        print("       RAIDEN OS KERNEL PANIC\n");
        print("========================================\n");
        print("\n");

        print("CPU EXCEPTION\n");

        print("VECTOR: ");
        print_uint64(vector);
        print("\n");

        print("TYPE: ");
        print(exception_name(vector));
        print("\n\n");

        print("SYSTEM HALTED\n");
    }


    while (1)
    {
        asm volatile ("hlt");
    }
}


/*
 * ============================================================
 * GRAPHICAL HEADER
 * ============================================================
 */

static void draw_desktop(void)
{
    if (!framebuffer_available())
    {
        return;
    }


    uint32_t width =
        framebuffer_get_width();


    uint32_t height =
        framebuffer_get_height();


    /*
     * Верхняя панель.
     */

    framebuffer_fill_rect(
        0,
        0,
        width,
        90,
        COLOR_PANEL
    );


    /*
     * Левая вертикальная панель.
     */

    framebuffer_fill_rect(
        0,
        90,
        250,
        height - 90,
        COLOR_PANEL2
    );


    /*
     * Акцентная линия.
     */

    framebuffer_fill_rect(
        0,
        88,
        width,
        2,
        COLOR_ACCENT
    );


    /*
     * Заголовок.
     */

    framebuffer_draw_string(
        32,
        28,
        "RAIDEN OS",
        COLOR_TEXT,
        4
    );


    framebuffer_draw_string(
        300,
        34,
        "KERNEL MODE",
        COLOR_TEXT_DIM,
        2
    );


    /*
     * Левая панель.

     */

    framebuffer_draw_string(
        30,
        125,
        "SYSTEM",
        COLOR_ACCENT,
        3
    );


    framebuffer_draw_string(
        30,
        175,
        "MEMORY",
        COLOR_TEXT,
        3
    );


    framebuffer_draw_string(
        30,
        220,
        "INTERRUPTS",
        COLOR_TEXT,
        3
    );


    framebuffer_draw_string(
        30,
        265,
        "TIMER",
        COLOR_TEXT,
        3
    );


    framebuffer_draw_string(
        30,
        310,
        "KEYBOARD",
        COLOR_TEXT,
        3
    );


    framebuffer_draw_string(
        30,
        355,
        "KERNEL",
        COLOR_TEXT,
        3
    );


    /*
     * Центральная область.
     */

    framebuffer_fill_rect(
        290,
        120,
        width - 330,
        height - 160,
        0x171A26FF
    );
}


static void draw_status(
    const char* label,
    const char* status,
    uint32_t y
)
{
    framebuffer_draw_string(
        330,
        y,
        label,
        COLOR_TEXT_DIM,
        3
    );


    framebuffer_draw_string(
        600,
        y,
        status,
        COLOR_SUCCESS,
        3
    );
}


/*
 * ============================================================
 * MAIN
 * ============================================================
 */

void kernel_main(
    uint32_t magic,
    uint32_t multiboot_info
)
{
    asm volatile ("cli");


    /*
     * ИСПРАВЛЕНИЕ: IDT грузим ПЕРВОЙ,
     * до любого обращения к framebuffer.
     *
     * Раньше framebuffer_clear() вызывался
     * до idt_init(), и если framebuffer
     * оказывался за пределами замапленной
     * памяти, CPU не мог доставить #PF
     * (IDT ещё не загружена) -> тройной
     * фолт -> QEMU молча ребутит машину.
     *
     * Теперь, даже если какой-то адрес
     * вдруг окажется не замаплен, вместо
     * тихого ребута будет корректный
     * экран "PAGE FAULT" из exception_handler().
     *
     * Печать "IDT: ONLINE" в консоль
     * остаётся ниже, на прежнем месте
     * в логе загрузки - сама инициализация
     * просто выполняется раньше.
     */

    idt_init();


    /*
     * Framebuffer должен быть
     * инициализирован ДО первого
     * графического вывода.
     */

    framebuffer_init(
        magic,
        multiboot_info
    );


    clear_screen();


    /*
     * Если framebuffer найден,
     * рисуем новый экран.
     */

    if (framebuffer_available())
    {
        draw_desktop();


        framebuffer_draw_string(
            330,
            145,
            "RAIDEN OS ONLINE",
            COLOR_SUCCESS,
            4
        );


        framebuffer_draw_string(
            330,
            215,
            "INITIALIZING KERNEL SYSTEMS",
            COLOR_TEXT_DIM,
            2
        );
    }
    else
    {
        print("========================================\n");
        print("          RAIDEN OS ONLINE\n");
        print("========================================\n");
        print("\n");

        print("FRAMEBUFFER: UNAVAILABLE\n");
        print("FALLBACK: VGA TEXT MODE\n\n");
    }


    /*
     * ========================================================
     * MEMORY
     * ========================================================
     */

    memory_init(
        magic,
        multiboot_info
    );


    print("\n[1] MEMORY MANAGER\n");


    /*
     * PMM
     */

    print("\n[2] PHYSICAL MEMORY MANAGER\n");


    pmm_init(
        magic,
        multiboot_info
    );


    print("PMM: ONLINE\n");


    print("TOTAL PAGES: ");


    print_uint64(
        pmm_get_total_pages()
    );


    print("\n");


    print("FREE PAGES: ");


    print_uint64(
        pmm_get_free_pages()
    );


    print("\n");


    /*
     * VMM
     */

    print("\n[3] VIRTUAL MEMORY MANAGER\n");


    vmm_init();


    print("VMM: ONLINE\n");


    uint64_t test_physical =
        pmm_alloc_page();


    if (test_physical != 0)
    {
        uint64_t test_virtual =
            0x00400000ULL;


        if (vmm_map_page(
                test_virtual,
                test_physical
            ))
        {
            volatile uint64_t* test =
                (volatile uint64_t*)
                test_virtual;


            *test =
                0x52414944454E4F53ULL;


            if (*test ==
                0x52414944454E4F53ULL)
            {
                print("VMM ACCESS: SUCCESS\n");
            }
            else
            {
                print("VMM ACCESS: FAILED\n");
            }


            vmm_unmap_page(
                test_virtual
            );


            pmm_free_page(
                test_physical
            );
        }
        else
        {
            print("VMM MAP: FAILED\n");


            pmm_free_page(
                test_physical
            );
        }
    }
    else
    {
        print("PMM ALLOCATION: FAILED\n");
    }


    /*
     * HEAP
     */

    print("\n[4] KERNEL HEAP\n");


    heap_init();


    print("HEAP: ONLINE\n");


    uint64_t before_heap =
        pmm_get_free_pages();


    void* memory =
        kmalloc(8192);


    if (memory != 0)
    {
        print("KMALLOC: SUCCESS\n");


        uint64_t after_alloc =
            pmm_get_free_pages();


        print("FREE PAGES AFTER ALLOC: ");


        print_uint64(
            after_alloc
        );


        print("\n");


        kfree(memory);


        uint64_t after_free =
            pmm_get_free_pages();


        print("FREE PAGES AFTER FREE: ");


        print_uint64(
            after_free
        );


        print("\n");


        if (after_free ==
            before_heap)
        {
            print("KFREE: SUCCESS\n");
        }
        else
        {
            print("KFREE: FAILED\n");
        }
    }
    else
    {
        print("KMALLOC: FAILED\n");
    }


    /*
     * IDT
     */

    print("\n[5] INTERRUPT DESCRIPTOR TABLE\n");


    /*
     * idt_init() уже был вызван в самом
     * начале kernel_main() (см. комментарий
     * выше) - здесь только строка лога.
     */

    print("IDT: ONLINE\n");
    print("CPU EXCEPTIONS: ONLINE\n");


    /*
     * PIC
     */

    print("\n[6] PROGRAMMABLE INTERRUPT CONTROLLER\n");


    pic_init();


    print("PIC: ONLINE\n");
    print("PIC REMAP: 32-47\n");


    /*
     * IRQ
     */

    print("\n[7] HARDWARE INTERRUPTS\n");


    irq_init();


    print("IRQ HANDLERS: ONLINE\n");


    /*
     * PIT
     */

    print("\n[8] SYSTEM TIMER\n");


    pit_init(100);


    print("PIT: ONLINE\n");
    print("FREQUENCY: 100 HZ\n");


    /*
     * Финальный графический статус.
     */

    if (framebuffer_available())
    {
        draw_desktop();


        framebuffer_draw_string(
            330,
            145,
            "RAIDEN OS ONLINE",
            COLOR_SUCCESS,
            4
        );


        framebuffer_draw_string(
            330,
            215,
            "ALL SYSTEMS OPERATIONAL",
            COLOR_TEXT,
            3
        );


        draw_status(
            "MEMORY MANAGER",
            "ONLINE",
            280
        );


        draw_status(
            "PHYSICAL MEMORY",
            "ONLINE",
            325
        );


        draw_status(
            "VIRTUAL MEMORY",
            "ONLINE",
            370
        );


        draw_status(
            "KERNEL HEAP",
            "ONLINE",
            415
        );


        draw_status(
            "IDT",
            "ONLINE",
            460
        );


        draw_status(
            "PIC",
            "ONLINE",
            505
        );


        draw_status(
            "PIT 100 HZ",
            "ONLINE",
            550
        );


        draw_status(
            "KEYBOARD IRQ1",
            "READY",
            595
        );


        framebuffer_draw_string(
            330,
            660,
            "HARDWARE INTERRUPTS ENABLED",
            COLOR_ACCENT,
            2
        );
    }
    else
    {
        print("\n========================================\n");
        print("        HARDWARE INTERRUPTS ONLINE\n");
        print("========================================\n");
        print("\n");

        print("PIC: ONLINE\n");
        print("IRQ0 TIMER: ONLINE\n");
        print("IRQ1 KEYBOARD: ONLINE\n");
        print("INTERRUPTS: ENABLED\n");
    }


    /*
     * Разрешаем аппаратные IRQ
     * только после полной настройки.
     */

    asm volatile ("sti");


    while (1)
    {
        asm volatile ("hlt");
    }
}
