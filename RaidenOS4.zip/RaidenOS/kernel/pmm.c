#include "pmm.h"
#include "memory.h"


/*
 * Максимальное количество физических страниц,
 * которое пока будем отслеживать.
 *
 * 128 MB / 4 KB = 32768 страниц.
 */
#define MAX_PAGES 32768


/*
 * Один бит = одна страница.
 *
 * 32768 бит = 4096 байт.
 */
static uint8_t page_bitmap[MAX_PAGES / 8];


/*
 * Общее количество страниц.
 */
static uint64_t total_pages = 0;


/*
 * Количество свободных страниц.
 */
static uint64_t free_pages = 0;


/*
 * Установить бит.
 *
 * 1 = страница занята.
 */
static void bitmap_set(uint64_t page)
{
    page_bitmap[page / 8] |=
        (1 << (page % 8));
}


/*
 * Сбросить бит.
 *
 * 0 = страница свободна.
 */
static void bitmap_clear(uint64_t page)
{
    page_bitmap[page / 8] &=
        ~(1 << (page % 8));
}


/*
 * Проверить состояние страницы.
 */
static int bitmap_test(uint64_t page)
{
    return
        page_bitmap[page / 8] &
        (1 << (page % 8));
}


/*
 * Инициализация Physical Memory Manager.
 */
void pmm_init(uint32_t magic, uint32_t multiboot_info)
{
    /*
     * Сначала считаем всю память занятой.
     *
     * Это безопаснее:
     * мы будем явно освобождать только
     * те области, которые GRUB назвал
     * доступными.
     */
    for (uint64_t i = 0; i < MAX_PAGES / 8; i++)
    {
        page_bitmap[i] = 0xFF;
    }


    total_pages = 0;
    free_pages = 0;


    /*
     * Проверяем Multiboot.
     */
    if (magic != 0x2BADB002)
    {
        return;
    }


    uint32_t* info =
        (uint32_t*)multiboot_info;


    uint32_t flags = info[0];


    /*
     * Memory Map отсутствует.
     */
    if (!(flags & (1 << 6)))
    {
        return;
    }


    /*
     * Получаем Memory Map.
     */
    uint32_t mmap_length = info[11];

    uint32_t mmap_addr = info[12];


    uint32_t current = mmap_addr;

    uint32_t end =
        mmap_addr + mmap_length;


    /*
     * Обходим Memory Map.
     */
    while (current < end)
    {
        multiboot_mmap_entry_t* entry =
            (multiboot_mmap_entry_t*)current;


        /*
         * Нас интересует только TYPE 1.
         */
        if (entry->type == 1)
{
    uint64_t base =
        entry->base;

    uint64_t length =
        entry->length;


    uint64_t first_page =
        (base + PAGE_SIZE - 1)
        / PAGE_SIZE;


    uint64_t last_page =
        (base + length)
        / PAGE_SIZE;


    for (uint64_t page = first_page;
         page < last_page;
         page++)
    {
        if (page < MAX_PAGES)
        {
            /*
             * Освобождаем страницу,
             * если она действительно была занята.
             */
            if (bitmap_test(page))
            {
                bitmap_clear(page);

                free_pages++;
            }
        }
    }
}


        /*
         * Следующая запись.
         */
        if (entry->size < 20)
        {
            break;
        }


        current +=
            entry->size + sizeof(entry->size);
    }


/*
 * Первые 2 MiB используются самой системой:
 *
 * - BIOS/GRUB области
 * - Multiboot
 * - наше ядро
 * - стек
 * - GDT
 * - page tables
 *
 * Поэтому не отдаём их allocator'у.
 */
uint64_t reserved_pages =
    (16 * 1024 * 1024) / PAGE_SIZE;


for (uint64_t page = 0;
     page < reserved_pages;
     page++)
{
    if (!bitmap_test(page))
    {
        bitmap_set(page);

        free_pages--;
    }
}
    /*
     * Считаем общее количество страниц.
     */
    total_pages = MAX_PAGES;
}


/*
 * Выдать одну физическую страницу.
 */
uint64_t pmm_alloc_page(void)
{
    for (uint64_t page = 0;
         page < MAX_PAGES;
         page++)
    {
        /*
         * Ищем свободную страницу.
         */
        if (!bitmap_test(page))
        {
            /*
             * Помечаем её занятой.
             */
            bitmap_set(page);

            free_pages--;


            /*
             * Возвращаем физический адрес.
             */
            return page * PAGE_SIZE;
        }
    }


    /*
     * Свободной памяти нет.
     */
    return 0;
}

/*
 * Выдать несколько последовательных физических страниц.
 */
uint64_t pmm_alloc_pages(uint64_t count)
{
    /*
     * Нельзя выделить ноль страниц.
     */
    if (count == 0)
    {
        return 0;
    }


    /*
     * Ищем последовательный свободный блок.
     */
    for (uint64_t start = 0;
         start < MAX_PAGES;
         start++)
    {
        /*
         * Проверяем, хватает ли места
         * до конца bitmap.
         */
        if (start + count > MAX_PAGES)
        {
            break;
        }


        /*
         * Проверяем все страницы блока.
         */
        int available = 1;


        for (uint64_t offset = 0;
             offset < count;
             offset++)
        {
            if (bitmap_test(start + offset))
            {
                available = 0;

                break;
            }
        }


        /*
         * Если весь блок свободен,
         * занимаем его.
         */
        if (available)
        {
            for (uint64_t offset = 0;
                 offset < count;
                 offset++)
            {
                bitmap_set(start + offset);
            }


            free_pages -= count;


            /*
             * Возвращаем адрес
             * первой страницы.
             */
            return start * PAGE_SIZE;
        }
    }


    /*
     * Подходящего блока нет.
     */
    return 0;
}

/*
 * Освободить физическую страницу.
 */
void pmm_free_page(uint64_t address)
{
    /*
     * Проверяем выравнивание.
     */
    if (address % PAGE_SIZE != 0)
    {
        return;
    }


    uint64_t page =
        address / PAGE_SIZE;


    if (page >= MAX_PAGES)
    {
        return;
    }


    /*
     * Если страница была занята,
     * освобождаем её.
     */
    if (bitmap_test(page))
    {
        bitmap_clear(page);

        free_pages++;
    }
}


/*
 * Получить количество всех страниц.
 */
uint64_t pmm_get_total_pages(void)
{
    return total_pages;
}


/*
 * Получить количество свободных страниц.
 */
uint64_t pmm_get_free_pages(void)
{
    return free_pages;
}
