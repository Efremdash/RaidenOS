BITS 64

extern exception_handler
extern irq_handler


section .text


; ============================================================
; CPU EXCEPTIONS
; ============================================================

isr_common_no_error:

    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov r12, rdi
    mov rdi, r12

    sub rsp, 8

    call exception_handler

    add rsp, 8

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    cli

.exception_hang:
    hlt
    jmp .exception_hang


isr_common_error:

    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov r12, rdi
    mov rdi, r12

    sub rsp, 8

    call exception_handler

    add rsp, 8

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    cli

.exception_error_hang:
    hlt
    jmp .exception_error_hang


; ============================================================
; EXCEPTION STUBS 0-31
; ============================================================

global isr0
isr0:
    mov rdi, 0
    jmp isr_common_no_error

global isr1
isr1:
    mov rdi, 1
    jmp isr_common_no_error

global isr2
isr2:
    mov rdi, 2
    jmp isr_common_no_error

global isr3
isr3:
    mov rdi, 3
    jmp isr_common_no_error

global isr4
isr4:
    mov rdi, 4
    jmp isr_common_no_error

global isr5
isr5:
    mov rdi, 5
    jmp isr_common_no_error

global isr6
isr6:
    mov rdi, 6
    jmp isr_common_no_error

global isr7
isr7:
    mov rdi, 7
    jmp isr_common_no_error

global isr8
isr8:
    mov rdi, 8
    jmp isr_common_error

global isr9
isr9:
    mov rdi, 9
    jmp isr_common_no_error

global isr10
isr10:
    mov rdi, 10
    jmp isr_common_error

global isr11
isr11:
    mov rdi, 11
    jmp isr_common_error

global isr12
isr12:
    mov rdi, 12
    jmp isr_common_error

global isr13
isr13:
    mov rdi, 13
    jmp isr_common_error

global isr14
isr14:
    mov rdi, 14
    jmp isr_common_error

global isr15
isr15:
    mov rdi, 15
    jmp isr_common_no_error

global isr16
isr16:
    mov rdi, 16
    jmp isr_common_no_error

global isr17
isr17:
    mov rdi, 17
    jmp isr_common_error

global isr18
isr18:
    mov rdi, 18
    jmp isr_common_no_error

global isr19
isr19:
    mov rdi, 19
    jmp isr_common_no_error

global isr20
isr20:
    mov rdi, 20
    jmp isr_common_no_error

global isr21
isr21:
    mov rdi, 21
    jmp isr_common_error

global isr22
isr22:
    mov rdi, 22
    jmp isr_common_no_error

global isr23
isr23:
    mov rdi, 23
    jmp isr_common_no_error

global isr24
isr24:
    mov rdi, 24
    jmp isr_common_no_error

global isr25
isr25:
    mov rdi, 25
    jmp isr_common_no_error

global isr26
isr26:
    mov rdi, 26
    jmp isr_common_no_error

global isr27
isr27:
    mov rdi, 27
    jmp isr_common_no_error

global isr28
isr28:
    mov rdi, 28
    jmp isr_common_no_error

global isr29
isr29:
    mov rdi, 29
    jmp isr_common_error

global isr30
isr30:
    mov rdi, 30
    jmp isr_common_error

global isr31
isr31:
    mov rdi, 31
    jmp isr_common_no_error


; ============================================================
; HARDWARE IRQ COMMON HANDLER
; ============================================================

irq_common:

    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    mov rbx, rsp

    and rsp, -16

    mov rdi, [rbx + 120]

    call irq_handler

    mov rsp, rbx

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    add rsp, 8

    iretq


; ============================================================
; IRQ STUBS 0-15
; ============================================================

global irq0
irq0:
    push qword 0
    jmp irq_common

global irq1
irq1:
    push qword 1
    jmp irq_common

global irq2
irq2:
    push qword 2
    jmp irq_common

global irq3
irq3:
    push qword 3
    jmp irq_common

global irq4
irq4:
    push qword 4
    jmp irq_common

global irq5
irq5:
    push qword 5
    jmp irq_common

global irq6
irq6:
    push qword 6
    jmp irq_common

global irq7
irq7:
    push qword 7
    jmp irq_common

global irq8
irq8:
    push qword 8
    jmp irq_common

global irq9
irq9:
    push qword 9
    jmp irq_common

global irq10
irq10:
    push qword 10
    jmp irq_common

global irq11
irq11:
    push qword 11
    jmp irq_common

global irq12
irq12:
    push qword 12
    jmp irq_common

global irq13
irq13:
    push qword 13
    jmp irq_common

global irq14
irq14:
    push qword 14
    jmp irq_common

global irq15
irq15:
    push qword 15
    jmp irq_common
