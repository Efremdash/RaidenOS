#include <stdio.h>

int main()
{
    printf("Hello from RaidenOS!\n");

    return 0;
}
